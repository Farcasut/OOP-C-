#include "Shark.h"

string Shark::GetName()
{
    return "Shark";
}
    bool Shark::IsABird()
    {
        return false;
    }

    bool Shark::IsAFish()
    {
        return true;
    }

    bool Shark::IsAMammal()
    {
        return false;
    }
