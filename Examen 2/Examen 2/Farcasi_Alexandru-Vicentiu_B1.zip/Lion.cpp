#include "Lion.h"

bool Lion::IsABird()
{
    return false;
}

bool Lion::IsAFish()
{
    return false;
}

bool Lion::IsAMammal()
{
    return true;
}

string Lion::GetName()
{
    return "Lion";
}

int Lion::GetSpeed()
{
    return 80;
}
