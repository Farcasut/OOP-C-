#include "Eagle.h"

string Eagle::GetName()
{
    return "Eagle";
}

bool Eagle::IsABird()
{
    return true;
}

bool Eagle::IsAFish()
{
    return false;
}

bool Eagle::IsAMammal()
{
    return false;
}
